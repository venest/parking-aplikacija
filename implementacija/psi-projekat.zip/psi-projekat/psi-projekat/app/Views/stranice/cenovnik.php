<div class="container text-center">
    <div class="jumbotron mb-1">
        <h1 class="display-4 mb-3">REGISTROVANI KORISNICI</h1><br>
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="alert alert-plavi py-4">
                    <h5>DNEVNA PRETPLATA</h5>
                    <h2 class="font-weight-bold">200 RSD</h2>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="alert alert-plavi py-4">
                    <h5>NEDELJNA PRETPLATA</h5>
                    <h2 class="font-weight-bold">800 RSD</h2>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="alert alert-plavi py-4">
                    <h5>MESEČNA PRETPLATA</h5>
                    <h2 class="font-weight-bold">2000 RSD</h2>
                </div>
            </div>
        </div>
    </div>
    <div class="jumbotron mb-1">
        <h1 class="display-4 mt-5">GOSTI</h1><br>
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="alert alert-plavi py-4">
                    <h2 class="font-weight-bold">60 RSD/SAT</h2>
                </div>
            </div>
        </div>
    </div>
</div>
