<div class="container text-center">
    <div class="jumbotron mb-1">
      <h1 class="display-4 mb-3">MAIL</h1><br>
      <div class="row">
        <div class="col-lg-6">
          <div class="alert alert-plavi py-4">
            <h5>Petar</h5>
            <p>pp170538d@student.etf.bg.ac.rs</p>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="alert alert-plavi py-4"> 
            <h5>Marina</h5>
            <p>sm170689d@student.etf.bg.ac.rs</p>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-6">
          <div class="alert alert-plavi py-4">  
            <h5>Mirko</h5>
            <p>sm170703d@student.etf.bg.ac.rs</p>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="alert alert-plavi py-4">  
            <h5>Veljko</h5>
            <p>nv170039d@student.etf.bg.ac.rs</p>
          </div>
        </div>
      </div>
    </div>
</div>