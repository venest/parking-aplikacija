<div class="container">
    <div class="alert alert-success text-center py-5">
        <h1>USPEŠNO STE SE REGISTROVALI.</h1>
        <hr>
        <h5> <a class="alert-link" href=<?php echo site_url('Gost/logovanje'); ?>>PRIJAVITE SE NA SVOJ NALOG.</a> </h5>
    </div>
</div>
