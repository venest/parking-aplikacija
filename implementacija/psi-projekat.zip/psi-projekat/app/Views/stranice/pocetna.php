<div class="container">
    <!-- nesto o aplikaciji -->
    <div class="jumbotron text-center">
        <h4 class="display-4 mb-5">PARKING APLIKACIJA</h4>
        <p class="lead">
            Aplikacija ima za cilj da simulira sistem naplate parkinga u javnim garažama. Osnovne 
            uloge u sistemu su: <strong>korisnik</strong> (gost i registrovani korisnik), <strong>kontrolor</strong>, 
            <strong>operater</strong> i <strong>admin</strong>. <br>
        </p>
    </div>   
</div>

